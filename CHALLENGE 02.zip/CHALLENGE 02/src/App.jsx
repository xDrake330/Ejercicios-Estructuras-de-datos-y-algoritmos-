import FirstApp from './components/FirstApp.jsx'

export default function App() {
  return (
    <main style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem' }}>
      <FirstApp />
    </main>
  )
}
