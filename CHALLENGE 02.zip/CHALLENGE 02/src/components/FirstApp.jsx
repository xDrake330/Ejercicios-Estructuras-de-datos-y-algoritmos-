export default function FirstApp() {
  const title = 'Mi Primer Título'
  return (
    <section>
      <h1>{title}</h1>
      <span>10</span>
    </section>
  )
}
