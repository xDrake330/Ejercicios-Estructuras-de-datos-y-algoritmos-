import { useAuth } from "../auth/AuthContext";

export default function Profile() {
  const { user } = useAuth();
  return (
    <section className="card">
      <h2 className="h2 mb-4">Perfil</h2>
      <div className="grid gap-2">
        <div>
          <p className="muted text-sm">Usuario actual</p>
          <p className="text-lg font-semibold">{user?.username}</p>
        </div>
      </div>
    </section>
  );
}
