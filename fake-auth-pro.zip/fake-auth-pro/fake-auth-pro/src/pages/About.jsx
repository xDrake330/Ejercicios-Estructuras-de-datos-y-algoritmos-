export default function About() {
  return (
    <section className="card">
      <h2 className="h2 mb-2">Acerca de</h2>
      <p className="muted">
        Este proyecto está pensado para práctica educativa: Context API, Providers, State y rutas públicas/privadas con React Router.
      </p>
    </section>
  );
}
