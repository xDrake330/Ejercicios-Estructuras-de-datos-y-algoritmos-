export default function Dashboard() {
  return (
    <section className="grid gap-6">
      <div className="card">
        <h2 className="h2 mb-2">Dashboard</h2>
        <p className="muted">Solo visible para usuarios autenticados.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-semibold mb-1">Métrica A</h3>
          <p className="text-4xl font-bold">42</p>
          <p className="muted text-sm">Últimas 24h</p>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-1">Métrica B</h3>
          <p className="text-4xl font-bold">97%</p>
          <p className="muted text-sm">Usuarios satisfechos</p>
        </div>
      </div>
    </section>
  );
}
