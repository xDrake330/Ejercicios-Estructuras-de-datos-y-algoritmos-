import { Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import Home from "./pages/Home";
import About from "./pages/About";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import ProtectedRoute from "./auth/ProtectedRoute";

export default function App() {
  return (
    <div className="min-h-full flex flex-col">
      <NavBar />
      <main className="container-pro py-8 flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />

          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
          </Route>

          <Route path="*" element={<h2 className="h2">404 - Not Found</h2>} />
        </Routes>
      </main>
      <footer className="border-t bg-white">
        <div className="container-pro py-6 text-sm text-slate-500">
          © {new Date().getFullYear()} FakeAuth Pro
        </div>
      </footer>
    </div>
  );
}
