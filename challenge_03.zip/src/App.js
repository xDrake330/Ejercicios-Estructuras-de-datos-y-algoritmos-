
import { Counter } from "./Counter";

function App() {
  return (
    <div>
      {/* Se pasa el valor inicial como prop */}
      <Counter defaultValue={10} />
    </div>
  );
}

export default App;
