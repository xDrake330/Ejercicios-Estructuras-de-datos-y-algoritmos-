import React, { useState } from 'react';
import ChildApp from './ChildApp.jsx';

export default function ParentApp() {
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState("");

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Gestión de Categorías</h1>
      <ChildApp 
        setCategories={setCategories} 
        setCategory={setCategory} 
      />
      <div style={{ marginTop: '1rem' }}>
        <h2>Categorías:</h2>
        <ul>
          {categories.map((cat, index) => (
            <li key={index} style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>
              {cat}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
