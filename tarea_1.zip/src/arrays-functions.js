
// Ejemplos de funciones de arreglos en JavaScript

// push() - Añade un elemento al final del arreglo
let numbers = [1, 2, 3, 4];
numbers.push(5);
console.log("push:", numbers); // [1, 2, 3, 4, 5]

// pop() - Elimina el último elemento
numbers.pop();
console.log("pop:", numbers); // [1, 2, 3, 4]

// shift() - Elimina el primer elemento
numbers.shift();
console.log("shift:", numbers); // [2, 3, 4]

// unshift() - Añade un elemento al principio
numbers.unshift(1);
console.log("unshift:", numbers); // [1, 2, 3, 4]

// splice() - Añade o elimina elementos en cualquier posición
numbers.splice(2, 0, 'a');
console.log("splice:", numbers); // [1, 2, 'a', 3, 4]

// forEach() - Ejecuta una función en cada elemento del arreglo
numbers.forEach(num => console.log("forEach:", num)); 

// map() - Crea un nuevo arreglo con los resultados de ejecutar una función
const squaredNumbers = numbers.map(num => num * num);
console.log("map:", squaredNumbers); // [1, 4, 9, 16]

// filter() - Crea un nuevo arreglo con los elementos que cumplen con la condición
const evenNumbers = numbers.filter(num => num % 2 === 0);
console.log("filter:", evenNumbers); // [2, 4]

// reduce() - Aplica una función acumulativa
const sum = numbers.reduce((acc, num) => acc + num, 0);
console.log("reduce:", sum); // 10

// some() - Verifica si al menos un elemento cumple con la condición
const hasEven = numbers.some(num => num % 2 === 0);
console.log("some:", hasEven); // true

// every() - Verifica si todos los elementos cumplen con la condición
const allEven = numbers.every(num => num % 2 === 0);
console.log("every:", allEven); // false

// find() - Encuentra el primer elemento que cumple con la condición
const found = numbers.find(num => num === 3);
console.log("find:", found); // 3

// findIndex() - Encuentra el índice del primer elemento que cumple con la condición
const index = numbers.findIndex(num => num === 3);
console.log("findIndex:", index); // 2

// indexOf() - Encuentra el índice del elemento especificado
const indexOfThree = numbers.indexOf(3);
console.log("indexOf:", indexOfThree); // 2

// sort() - Ordena los elementos del arreglo
numbers.sort((a, b) => a - b);
console.log("sort:", numbers); // [1, 2, 3, 4]

// reverse() - Invierte el orden de los elementos
numbers.reverse();
console.log("reverse:", numbers); // [4, 3, 2, 1]

// concat() - Combina dos o más arreglos
const newArray = numbers.concat([5, 6]);
console.log("concat:", newArray); // [4, 3, 2, 1, 5, 6]

// join() - Une todos los elementos del arreglo en una cadena
const joined = numbers.join(", ");
console.log("join:", joined); // "4, 3, 2, 1"

// slice() - Devuelve una copia superficial de una porción del arreglo
const sliced = numbers.slice(1, 3);
console.log("slice:", sliced); // [3, 2]
