
# Tarea 1 - Funciones de Arreglos en JavaScript

En esta tarea se demuestran los ejemplos de las funciones más comunes de arreglos en JavaScript. Se incluye el uso de métodos de mutación, iteración, búsqueda, ordenación y otros métodos útiles para manejar arreglos.

## Métodos utilizados:
- Métodos de mutación: push(), pop(), shift(), unshift(), splice().
- Métodos de iteración: forEach(), map(), filter(), reduce(), some(), every().
- Métodos de búsqueda: find(), findIndex(), indexOf().
- Métodos de ordenación: sort(), reverse().
- Otros métodos: concat(), join(), slice().
